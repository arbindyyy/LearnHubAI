import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import memorystore from "memorystore";
import { z } from "zod";
import { 
  insertUserSchema, insertCategorySchema, insertCalculatorSchema, insertHistorySchema,
  loginSchema, calculationSchema
} from "@shared/schema";

const MemoryStore = memorystore(session);

// Helper function to verify admin access
function isAdmin(req: Request, res: Response): boolean {
  if (!req.session.user || !req.session.user.isAdmin) {
    res.status(403).json({ message: "Unauthorized: Admin access required" });
    return false;
  }
  return true;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session middleware
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new MemoryStore({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
      resave: false,
      secret: "calculator-app-secret",
      saveUninitialized: false
    })
  );

  // Authentication routes
  app.post("/api/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(data.username);

      if (!user || user.password !== data.password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Store user in session (excluding password)
      req.session.user = {
        id: user.id,
        username: user.username,
        isAdmin: user.isAdmin
      };

      res.json({ 
        id: user.id,
        username: user.username,
        isAdmin: user.isAdmin,
        preferences: user.preferences
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/logout", (req, res) => {
    req.session.destroy(err => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/me", (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.session.user);
  });

  // User preferences
  app.put("/api/user/preferences", async (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const preferences = req.body;
      const updatedUser = await storage.updateUserPreferences(req.session.user.id, preferences);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update session
      req.session.user = {
        ...req.session.user,
        preferences: updatedUser.preferences
      };
      
      res.json({ preferences: updatedUser.preferences });
    } catch (error) {
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // Categories routes
  app.get("/api/categories", async (_req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });
  
  app.get("/api/categories/:slug", async (req, res) => {
    try {
      const slug = req.params.slug;
      const category = await storage.getCategoryBySlug(slug);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    if (!isAdmin(req, res)) return;
    
    try {
      const data = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(data);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.put("/api/categories/:id", async (req, res) => {
    if (!isAdmin(req, res)) return;
    
    try {
      const id = parseInt(req.params.id);
      const data = insertCategorySchema.partial().parse(req.body);
      const category = await storage.updateCategory(id, data);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  app.delete("/api/categories/:id", async (req, res) => {
    if (!isAdmin(req, res)) return;
    
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteCategory(id);
      
      if (!success) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json({ message: "Category deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // Calculator routes
  app.get("/api/calculators", async (_req, res) => {
    try {
      const calculators = await storage.getAllCalculators();
      res.json(calculators);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculators" });
    }
  });
  
  app.get("/api/calculators/popular", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const calculators = await storage.getPopularCalculators(limit);
      res.json(calculators);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch popular calculators" });
    }
  });

  app.get("/api/calculators/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const calculators = await storage.searchCalculators(query);
      res.json(calculators);
    } catch (error) {
      res.status(500).json({ message: "Failed to search calculators" });
    }
  });

  app.get("/api/calculators/category/:categoryId", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.categoryId);
      const calculators = await storage.getCalculatorsByCategory(categoryId);
      res.json(calculators);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculators by category" });
    }
  });
  
  app.get("/api/calculators/slug/:slug", async (req, res) => {
    try {
      const slug = req.params.slug;
      const calculator = await storage.getCalculatorBySlug(slug);
      
      if (!calculator) {
        return res.status(404).json({ message: "Calculator not found" });
      }
      
      await storage.incrementPopularity(calculator.id);
      
      // Get category information
      const fullCalculator = await storage.getCalculatorWithCategory(calculator.id);
      
      res.json(fullCalculator);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculator" });
    }
  });

  app.get("/api/calculators/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const calculator = await storage.getCalculatorWithCategory(id);
      
      if (!calculator) {
        return res.status(404).json({ message: "Calculator not found" });
      }
      
      await storage.incrementPopularity(id);
      
      res.json(calculator);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculator" });
    }
  });

  app.post("/api/calculators", async (req, res) => {
    if (!isAdmin(req, res)) return;
    
    try {
      const data = insertCalculatorSchema.parse(req.body);
      const calculator = await storage.createCalculator(data);
      res.status(201).json(calculator);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create calculator" });
    }
  });

  app.put("/api/calculators/:id", async (req, res) => {
    if (!isAdmin(req, res)) return;
    
    try {
      const id = parseInt(req.params.id);
      const data = insertCalculatorSchema.partial().parse(req.body);
      const calculator = await storage.updateCalculator(id, data);
      
      if (!calculator) {
        return res.status(404).json({ message: "Calculator not found" });
      }
      
      res.json(calculator);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to update calculator" });
    }
  });

  app.delete("/api/calculators/:id", async (req, res) => {
    if (!isAdmin(req, res)) return;
    
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteCalculator(id);
      
      if (!success) {
        return res.status(404).json({ message: "Calculator not found" });
      }
      
      res.json({ message: "Calculator deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete calculator" });
    }
  });
  
  // Calculation route - execute a calculation
  app.post("/api/calculate", async (req, res) => {
    try {
      const data = calculationSchema.parse(req.body);
      const calculator = await storage.getCalculator(data.calculatorId);
      
      if (!calculator) {
        return res.status(404).json({ message: "Calculator not found" });
      }
      
      // In a real app, we would execute the calculation here based on the calculator type
      // For this demo, we'll simulate the calculation with a placeholder
      const result = {
        calculatorId: calculator.id,
        calculatorName: calculator.name,
        inputs: data.inputs,
        result: { value: 123.45 }, // This would be the actual calculation result
        timestamp: new Date()
      };
      
      // Increment popularity count for this calculator
      await storage.incrementPopularity(calculator.id);
      
      // Save to history if user is logged in
      if (req.session.user) {
        await storage.createHistory({
          userId: req.session.user.id,
          calculatorId: calculator.id,
          inputs: data.inputs,
          result: result.result,
          notes: ""
        });
      }
      
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to process calculation" });
    }
  });

  // History routes
  app.get("/api/history", async (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const history = await storage.getUserHistory(req.session.user.id);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });
  
  app.post("/api/history", async (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const data = insertHistorySchema.parse({
        ...req.body,
        userId: req.session.user.id
      });
      
      const history = await storage.createHistory(data);
      res.status(201).json(history);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to save calculation history" });
    }
  });
  
  app.delete("/api/history/:id", async (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteHistory(id);
      
      if (!success) {
        return res.status(404).json({ message: "History entry not found" });
      }
      
      res.json({ message: "History entry deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete history entry" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
