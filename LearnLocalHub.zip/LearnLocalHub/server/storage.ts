import { 
  users, categories, calculators, history,
  type User, type InsertUser, 
  type Category, type InsertCategory,
  type Calculator, type InsertCalculator,
  type History, type InsertHistory,
  type CalculatorWithCategory
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPreferences(id: number, preferences: any): Promise<User | undefined>;
  
  // Category operations
  getAllCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Calculator operations
  getAllCalculators(): Promise<Calculator[]>;
  getCalculator(id: number): Promise<Calculator | undefined>;
  getCalculatorBySlug(slug: string): Promise<Calculator | undefined>;
  getCalculatorWithCategory(id: number): Promise<CalculatorWithCategory | undefined>;
  getCalculatorsByCategory(categoryId: number): Promise<Calculator[]>;
  createCalculator(calculator: InsertCalculator): Promise<Calculator>;
  updateCalculator(id: number, calculator: Partial<InsertCalculator>): Promise<Calculator | undefined>;
  deleteCalculator(id: number): Promise<boolean>;
  searchCalculators(query: string): Promise<Calculator[]>;
  incrementPopularity(id: number): Promise<void>;
  getPopularCalculators(limit: number): Promise<Calculator[]>;
  
  // History operations
  getUserHistory(userId: number): Promise<History[]>;
  getHistoryForCalculator(calculatorId: number, userId?: number): Promise<History[]>;
  createHistory(history: InsertHistory): Promise<History>;
  deleteHistory(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private calculators: Map<number, Calculator>;
  private historyItems: Map<number, History>;
  
  private userId: number;
  private categoryId: number;
  private calculatorId: number;
  private historyId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.calculators = new Map();
    this.historyItems = new Map();
    
    this.userId = 1;
    this.categoryId = 1;
    this.calculatorId = 1;
    this.historyId = 1;
    
    // Add initial admin user
    this.createUser({
      username: "admin",
      password: "password123", // In a real app, this would be hashed
      isAdmin: true,
      preferences: {
        theme: "light",
        favoriteCalculators: [],
        recentCalculators: []
      }
    });
    
    // Add initial calculator categories
    this.createCategory({ 
      name: "Financial", 
      description: "Financial and investment calculators", 
      icon: "calculator",
      slug: "financial",
      order: 1
    });
    
    this.createCategory({ 
      name: "Health", 
      description: "Health and fitness calculators", 
      icon: "heart",
      slug: "health",
      order: 2
    });
    
    this.createCategory({ 
      name: "Math", 
      description: "Mathematical and scientific calculators", 
      icon: "pi",
      slug: "math",
      order: 3
    });
    
    this.createCategory({ 
      name: "Conversion", 
      description: "Unit conversion calculators", 
      icon: "repeat",
      slug: "conversion",
      order: 4
    });
    
    this.createCategory({ 
      name: "Date & Time", 
      description: "Date and time calculators", 
      icon: "calendar",
      slug: "date-time",
      order: 5
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserPreferences(id: number, preferences: any): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = {
      ...user,
      preferences: {
        ...user.preferences,
        ...preferences
      }
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Category operations
  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values())
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug
    );
  }
  
  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryId++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }
  
  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const existingCategory = this.categories.get(id);
    if (!existingCategory) return undefined;
    
    const updatedCategory = { ...existingCategory, ...category };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    return this.categories.delete(id);
  }
  
  // Calculator operations
  async getAllCalculators(): Promise<Calculator[]> {
    return Array.from(this.calculators.values());
  }
  
  async getCalculator(id: number): Promise<Calculator | undefined> {
    return this.calculators.get(id);
  }
  
  async getCalculatorBySlug(slug: string): Promise<Calculator | undefined> {
    return Array.from(this.calculators.values()).find(
      (calculator) => calculator.slug === slug
    );
  }
  
  async getCalculatorWithCategory(id: number): Promise<CalculatorWithCategory | undefined> {
    const calculator = this.calculators.get(id);
    if (!calculator) return undefined;
    
    const category = calculator.categoryId ? await this.getCategory(calculator.categoryId) : undefined;
    
    return {
      ...calculator,
      category
    };
  }
  
  async getCalculatorsByCategory(categoryId: number): Promise<Calculator[]> {
    return Array.from(this.calculators.values()).filter(
      (calculator) => calculator.categoryId === categoryId
    );
  }
  
  async createCalculator(calculator: InsertCalculator): Promise<Calculator> {
    const id = this.calculatorId++;
    const now = new Date();
    const newCalculator: Calculator = { 
      ...calculator, 
      id, 
      createdAt: now,
      popularity: 0
    };
    this.calculators.set(id, newCalculator);
    return newCalculator;
  }
  
  async updateCalculator(id: number, calculator: Partial<InsertCalculator>): Promise<Calculator | undefined> {
    const existingCalculator = this.calculators.get(id);
    if (!existingCalculator) return undefined;
    
    const updatedCalculator = { ...existingCalculator, ...calculator };
    this.calculators.set(id, updatedCalculator);
    return updatedCalculator;
  }
  
  async deleteCalculator(id: number): Promise<boolean> {
    return this.calculators.delete(id);
  }
  
  async searchCalculators(query: string): Promise<Calculator[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.calculators.values()).filter(
      (calculator) => 
        calculator.name.toLowerCase().includes(lowerQuery) ||
        calculator.description.toLowerCase().includes(lowerQuery) ||
        (calculator.formulaExplanation && calculator.formulaExplanation.toLowerCase().includes(lowerQuery))
    );
  }
  
  async incrementPopularity(id: number): Promise<void> {
    const calculator = this.calculators.get(id);
    if (calculator) {
      calculator.popularity += 1;
      this.calculators.set(id, calculator);
    }
  }
  
  async getPopularCalculators(limit: number): Promise<Calculator[]> {
    return Array.from(this.calculators.values())
      .sort((a, b) => b.popularity - a.popularity)
      .slice(0, limit);
  }
  
  // History operations
  async getUserHistory(userId: number): Promise<History[]> {
    return Array.from(this.historyItems.values())
      .filter(item => item.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getHistoryForCalculator(calculatorId: number, userId?: number): Promise<History[]> {
    let items = Array.from(this.historyItems.values())
      .filter(item => item.calculatorId === calculatorId);
    
    if (userId) {
      items = items.filter(item => item.userId === userId);
    }
    
    return items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async createHistory(insertHistory: InsertHistory): Promise<History> {
    const id = this.historyId++;
    const now = new Date();
    const newHistory: History = { ...insertHistory, id, createdAt: now };
    this.historyItems.set(id, newHistory);
    return newHistory;
  }
  
  async deleteHistory(id: number): Promise<boolean> {
    return this.historyItems.delete(id);
  }
}

export const storage = new MemStorage();
