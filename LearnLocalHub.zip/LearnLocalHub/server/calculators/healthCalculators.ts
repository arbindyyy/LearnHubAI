import { Calculator, InsertCalculator, FieldType } from "@shared/schema";
import { storage } from "../storage";

// Health calculators
export const healthCalculators: InsertCalculator[] = [
  {
    name: "BMI Calculator",
    description: "Calculate your Body Mass Index (BMI) to determine if you are underweight, normal weight, overweight, or obese",
    slug: "bmi-calculator",
    categoryId: 2, // Health category
    formula: "BMI = weight(kg) / (height(m))²",
    formulaExplanation: "BMI is calculated by dividing your weight in kilograms by the square of your height in meters. The result indicates whether you are underweight, normal weight, overweight, or obese.",
    icon: "heart",
    usage: "Enter your height and weight to calculate your BMI. The result will show your BMI value and weight category.",
    examples: {
      inputs: [
        { weight: 70, height: 175, unit: "metric" }
      ],
      outputs: [
        { value: 22.86, unit: "kg/m²" }
      ]
    },
    defaultValues: {
      weight: 70,
      height: 170,
      unit: "metric"
    },
    fields: [
      {
        name: "unit",
        label: "Unit System",
        type: FieldType.SELECT,
        required: true,
        options: ["metric", "imperial"],
        helpText: "Choose between metric (kg, cm) or imperial (lb, in) units"
      },
      {
        name: "weight",
        label: "Weight",
        type: FieldType.NUMBER,
        required: true,
        min: 20,
        max: 500,
        placeholder: "Enter your weight",
        helpText: "Your current weight",
        unit: "kg"
      },
      {
        name: "height",
        label: "Height",
        type: FieldType.NUMBER,
        required: true,
        min: 50,
        max: 250,
        placeholder: "Enter your height",
        helpText: "Your height in centimeters",
        unit: "cm"
      }
    ]
  },
  {
    name: "Daily Calorie Calculator",
    description: "Calculate your daily calorie needs based on your age, gender, weight, height, and activity level",
    slug: "daily-calorie-calculator",
    categoryId: 2, // Health category
    formula: "BMR = 10 × weight(kg) + 6.25 × height(cm) - 5 × age + s (s=5 for men, s=-161 for women)",
    formulaExplanation: "Basal Metabolic Rate (BMR) is calculated using the Mifflin-St Jeor equation. Daily calorie needs = BMR × activity factor.",
    icon: "heart",
    usage: "Enter your personal details and activity level to get an estimate of how many calories you need daily to maintain your current weight.",
    examples: {
      inputs: [
        { age: 30, gender: "male", weight: 75, height: 175, activityLevel: "moderately active" }
      ],
      outputs: [
        { value: 2550, unit: "calories/day" }
      ]
    },
    defaultValues: {
      age: 30,
      gender: "male",
      weight: 70,
      height: 170,
      activityLevel: "moderately active"
    },
    fields: [
      {
        name: "age",
        label: "Age",
        type: FieldType.NUMBER,
        required: true,
        min: 15,
        max: 100,
        placeholder: "Enter your age",
        helpText: "Your age in years"
      },
      {
        name: "gender",
        label: "Gender",
        type: FieldType.SELECT,
        required: true,
        options: ["male", "female"],
        helpText: "Your biological gender (for calculation purposes)"
      },
      {
        name: "weight",
        label: "Weight",
        type: FieldType.NUMBER,
        required: true,
        min: 30,
        max: 300,
        placeholder: "Enter your weight",
        helpText: "Your current weight",
        unit: "kg"
      },
      {
        name: "height",
        label: "Height",
        type: FieldType.NUMBER,
        required: true,
        min: 100,
        max: 250,
        placeholder: "Enter your height",
        helpText: "Your height",
        unit: "cm"
      },
      {
        name: "activityLevel",
        label: "Activity Level",
        type: FieldType.SELECT,
        required: true,
        options: ["sedentary", "lightly active", "moderately active", "very active", "extremely active"],
        helpText: "Your typical daily activity level"
      }
    ]
  },
  {
    name: "Body Fat Percentage Calculator",
    description: "Estimate your body fat percentage based on measurements",
    slug: "body-fat-calculator",
    categoryId: 2, // Health category
    formula: "Body Fat % (men) = 495 / (1.0324 - 0.19077 × log10(waist - neck) + 0.15456 × log10(height)) - 450",
    formulaExplanation: "This calculator uses the US Navy method which estimates body fat percentage based on height and circumference measurements at specific body parts.",
    icon: "heart",
    usage: "Enter your gender, height, and body measurements to estimate your body fat percentage.",
    examples: {
      inputs: [
        { gender: "male", height: 175, neck: 38, waist: 85, hip: 0 }
      ],
      outputs: [
        { value: 15.3, unit: "%" }
      ]
    },
    defaultValues: {
      gender: "male",
      height: 175,
      neck: 38,
      waist: 85,
      hip: 96
    },
    fields: [
      {
        name: "gender",
        label: "Gender",
        type: FieldType.SELECT,
        required: true,
        options: ["male", "female"],
        helpText: "Your biological gender (for calculation purposes)"
      },
      {
        name: "height",
        label: "Height",
        type: FieldType.NUMBER,
        required: true,
        min: 100,
        max: 250,
        placeholder: "Enter your height",
        helpText: "Your height",
        unit: "cm"
      },
      {
        name: "neck",
        label: "Neck Circumference",
        type: FieldType.NUMBER,
        required: true,
        min: 20,
        max: 80,
        placeholder: "Enter neck circumference",
        helpText: "Measure around your neck at the narrowest point",
        unit: "cm"
      },
      {
        name: "waist",
        label: "Waist Circumference",
        type: FieldType.NUMBER,
        required: true,
        min: 40,
        max: 200,
        placeholder: "Enter waist circumference",
        helpText: "For men: measure at navel level. For women: at the narrowest point",
        unit: "cm"
      },
      {
        name: "hip",
        label: "Hip Circumference",
        type: FieldType.NUMBER,
        required: false,
        min: 50,
        max: 200,
        placeholder: "Enter hip circumference (women only)",
        helpText: "Only required for women. Measure at the widest point around hips",
        unit: "cm"
      }
    ]
  }
];

// Add health calculators to database
export async function addHealthCalculators(): Promise<void> {
  for (const calculator of healthCalculators) {
    const existing = await storage.getCalculatorBySlug(calculator.slug);
    if (!existing) {
      await storage.createCalculator(calculator);
    }
  }
}