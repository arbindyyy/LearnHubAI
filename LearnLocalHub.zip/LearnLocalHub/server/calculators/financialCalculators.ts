import { Calculator, InsertCalculator, FieldType } from "@shared/schema";
import { storage } from "../storage";

// Financial calculators
export const financialCalculators: InsertCalculator[] = [
  {
    name: "EMI Calculator",
    description: "Calculate your Equated Monthly Installment (EMI) for home, car, personal, and other loans",
    slug: "emi-calculator",
    categoryId: 1, // Financial category
    formula: "EMI = P × r × (1 + r)^n / ((1 + r)^n - 1)",
    formulaExplanation: "Where P is the principal loan amount, r is the interest rate per month [r = (annual interest rate ÷ 12) ÷ 100], and n is the loan tenure in months.",
    icon: "calculator",
    usage: "Enter the loan amount, interest rate (annual), and loan tenure to calculate your monthly EMI payment.",
    examples: {
      inputs: [
        { principal: 100000, interestRate: 10, loanTenure: 12 }
      ],
      outputs: [
        { value: 8792.44, unit: "per month" }
      ]
    },
    defaultValues: {
      principal: 100000,
      interestRate: 10,
      loanTenure: 12
    },
    fields: [
      {
        name: "principal",
        label: "Loan Amount",
        type: FieldType.NUMBER,
        required: true,
        min: 1000,
        placeholder: "Enter loan amount",
        helpText: "The total amount of loan you are taking",
        unit: "₹"
      },
      {
        name: "interestRate",
        label: "Interest Rate",
        type: FieldType.NUMBER,
        required: true,
        min: 1,
        max: 50,
        placeholder: "Enter annual interest rate",
        helpText: "Annual interest rate (in percentage)",
        unit: "%"
      },
      {
        name: "loanTenure",
        label: "Loan Tenure",
        type: FieldType.NUMBER,
        required: true,
        min: 1,
        max: 360,
        placeholder: "Enter loan tenure in months",
        helpText: "The duration of the loan in months",
        unit: "months"
      }
    ]
  },
  {
    name: "Simple Interest Calculator",
    description: "Calculate simple interest on your investments or loans",
    slug: "simple-interest-calculator",
    categoryId: 1, // Financial category
    formula: "Simple Interest = (P × r × t) / 100",
    formulaExplanation: "Where P is the principal amount, r is the annual interest rate in percentage, and t is the time period in years.",
    icon: "calculator",
    usage: "Enter the principal amount, interest rate, and time period to calculate the simple interest.",
    examples: {
      inputs: [
        { principal: 10000, interestRate: 5, timePeriod: 3 }
      ],
      outputs: [
        { value: 1500, unit: "" }
      ]
    },
    defaultValues: {
      principal: 10000,
      interestRate: 5,
      timePeriod: 3
    },
    fields: [
      {
        name: "principal",
        label: "Principal Amount",
        type: FieldType.NUMBER,
        required: true,
        min: 100,
        placeholder: "Enter principal amount",
        helpText: "The initial amount of money",
        unit: "₹"
      },
      {
        name: "interestRate",
        label: "Interest Rate",
        type: FieldType.NUMBER,
        required: true,
        min: 0.1,
        max: 50,
        placeholder: "Enter annual interest rate",
        helpText: "Annual interest rate (in percentage)",
        unit: "%"
      },
      {
        name: "timePeriod",
        label: "Time Period",
        type: FieldType.NUMBER,
        required: true,
        min: 0.1,
        max: 30,
        placeholder: "Enter time period in years",
        helpText: "The time period for the investment or loan",
        unit: "years"
      }
    ]
  },
  {
    name: "Compound Interest Calculator",
    description: "Calculate compound interest on your investments",
    slug: "compound-interest-calculator",
    categoryId: 1, // Financial category
    formula: "A = P(1 + r/n)^(nt)",
    formulaExplanation: "Where A is the final amount, P is the principal, r is the annual interest rate (decimal), n is the number of times interest is compounded per year, and t is the time in years.",
    icon: "calculator",
    usage: "Enter the principal amount, annual interest rate, compounding frequency, and time period to calculate the total amount and interest earned.",
    examples: {
      inputs: [
        { principal: 10000, interestRate: 8, compoundingFrequency: "quarterly", timePeriod: 5 }
      ],
      outputs: [
        { value: 14859.47, unit: "" }
      ]
    },
    defaultValues: {
      principal: 10000,
      interestRate: 8,
      compoundingFrequency: "annually",
      timePeriod: 5
    },
    fields: [
      {
        name: "principal",
        label: "Principal Amount",
        type: FieldType.NUMBER,
        required: true,
        min: 100,
        placeholder: "Enter principal amount",
        helpText: "The initial investment amount",
        unit: "₹"
      },
      {
        name: "interestRate",
        label: "Interest Rate",
        type: FieldType.NUMBER,
        required: true,
        min: 0.1,
        max: 50,
        placeholder: "Enter annual interest rate",
        helpText: "Annual interest rate (in percentage)",
        unit: "%"
      },
      {
        name: "compoundingFrequency",
        label: "Compounding Frequency",
        type: FieldType.SELECT,
        required: true,
        options: ["annually", "semi-annually", "quarterly", "monthly", "daily"],
        helpText: "How often the interest is compounded"
      },
      {
        name: "timePeriod",
        label: "Time Period",
        type: FieldType.NUMBER,
        required: true,
        min: 0.1,
        max: 50,
        placeholder: "Enter time period in years",
        helpText: "The time period for the investment",
        unit: "years"
      }
    ]
  }
];

// Add financial calculators to database
export async function addFinancialCalculators(): Promise<void> {
  for (const calculator of financialCalculators) {
    const existing = await storage.getCalculatorBySlug(calculator.slug);
    if (!existing) {
      await storage.createCalculator(calculator);
    }
  }
}