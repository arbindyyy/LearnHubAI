import { storage } from "../storage";
import { addFinancialCalculators } from "./financialCalculators";
import { addHealthCalculators } from "./healthCalculators";
import { addMathCalculators } from "./mathCalculators";

/**
 * Initialize all calculator data
 * This adds calculator data to the database if it doesn't already exist
 */
export async function initCalculators(): Promise<void> {
  // Initialize categories if they don't exist
  const existingCategories = await storage.getAllCategories();
  
  if (existingCategories.length === 0) {
    console.log("Initializing calculator categories...");
    
    // Add categories
    await storage.createCategory({
      name: "Financial",
      description: "Financial and investment calculators",
      icon: "calculator",
      slug: "financial",
      order: 1
    });
    
    await storage.createCategory({
      name: "Health",
      description: "Health and fitness calculators",
      icon: "heart",
      slug: "health",
      order: 2
    });
    
    await storage.createCategory({
      name: "Math",
      description: "Mathematical and scientific calculators",
      icon: "pi",
      slug: "math",
      order: 3
    });
    
    await storage.createCategory({
      name: "Conversion",
      description: "Unit conversion calculators",
      icon: "repeat",
      slug: "conversion",
      order: 4
    });
    
    await storage.createCategory({
      name: "Date & Time",
      description: "Date and time calculators",
      icon: "calendar",
      slug: "date-time",
      order: 5
    });
  }
  
  // Add calculators
  console.log("Initializing calculators...");
  await addFinancialCalculators();
  await addHealthCalculators();
  await addMathCalculators();
  
  console.log("Calculator initialization complete!");
}