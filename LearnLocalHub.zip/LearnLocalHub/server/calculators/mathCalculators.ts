import { Calculator, InsertCalculator, FieldType } from "@shared/schema";
import { storage } from "../storage";

// Math calculators
export const mathCalculators: InsertCalculator[] = [
  {
    name: "Percentage Calculator",
    description: "Calculate percentages with ease - find what percent one number is of another, calculate percentage increase or decrease",
    slug: "percentage-calculator",
    categoryId: 3, // Math category
    formula: "X% of Y = (X / 100) × Y",
    formulaExplanation: "To find X% of Y, multiply Y by X/100. To find what percent X is of Y, divide X by Y and multiply by 100.",
    icon: "percent",
    usage: "Enter values in the fields below based on what you want to calculate.",
    examples: {
      inputs: [
        { calculationType: "percent-of", percent: 15, value: 200 }
      ],
      outputs: [
        { value: 30, unit: "" }
      ]
    },
    defaultValues: {
      calculationType: "percent-of",
      percent: 15,
      value: 200,
      originalValue: 200,
      newValue: 240
    },
    fields: [
      {
        name: "calculationType",
        label: "Calculation Type",
        type: FieldType.SELECT,
        required: true,
        options: ["percent-of", "percent-change", "percent-one-of-another"],
        helpText: "Select the type of percentage calculation you need"
      },
      {
        name: "percent",
        label: "Percentage",
        type: FieldType.NUMBER,
        required: true,
        min: 0,
        max: 1000,
        placeholder: "Enter percentage",
        helpText: "The percentage value",
        unit: "%"
      },
      {
        name: "value",
        label: "Value",
        type: FieldType.NUMBER,
        required: true,
        placeholder: "Enter value",
        helpText: "The total value to calculate percentage of"
      },
      {
        name: "originalValue",
        label: "Original Value",
        type: FieldType.NUMBER,
        required: false,
        placeholder: "Enter original value",
        helpText: "The starting value (for percentage change)"
      },
      {
        name: "newValue",
        label: "New Value",
        type: FieldType.NUMBER,
        required: false,
        placeholder: "Enter new value",
        helpText: "The ending value (for percentage change)"
      }
    ]
  },
  {
    name: "Scientific Calculator",
    description: "Perform advanced mathematical calculations including trigonometric, logarithmic, and exponential functions",
    slug: "scientific-calculator",
    categoryId: 3, // Math category
    formula: "Various mathematical formulas depending on the operation",
    formulaExplanation: "This calculator implements standard mathematical operations, trigonometric functions, logarithms, exponentiation, and more.",
    icon: "calculator",
    usage: "Enter a mathematical expression using numbers, operators, and functions to calculate the result.",
    examples: {
      inputs: [
        { expression: "sin(45) * sqrt(16) + log(10)" }
      ],
      outputs: [
        { value: 3.708, unit: "" }
      ]
    },
    defaultValues: {
      expression: "sin(45) * 2 + 3"
    },
    fields: [
      {
        name: "expression",
        label: "Mathematical Expression",
        type: FieldType.TEXT,
        required: true,
        placeholder: "Enter a mathematical expression",
        helpText: "Enter a mathematical expression using operators (+, -, *, /, ^), functions (sin, cos, tan, log, ln, sqrt), and constants (pi, e)"
      }
    ]
  },
  {
    name: "Area Calculator",
    description: "Calculate the area of various geometric shapes like rectangles, circles, triangles, and more",
    slug: "area-calculator",
    categoryId: 3, // Math category
    formula: "Area formulas:\nRectangle: A = l × w\nCircle: A = π × r²\nTriangle: A = (b × h) / 2",
    formulaExplanation: "Different formulas are used depending on the shape selected. The calculator automatically applies the appropriate formula based on your input.",
    icon: "square",
    usage: "Select a shape and enter the required dimensions to calculate its area.",
    examples: {
      inputs: [
        { shape: "circle", radius: 5 }
      ],
      outputs: [
        { value: 78.54, unit: "square units" }
      ]
    },
    defaultValues: {
      shape: "rectangle",
      length: 10,
      width: 5,
      radius: 5,
      base: 8,
      height: 6
    },
    fields: [
      {
        name: "shape",
        label: "Shape",
        type: FieldType.SELECT,
        required: true,
        options: ["rectangle", "circle", "triangle", "square"],
        helpText: "Select the geometric shape you want to calculate the area for"
      },
      {
        name: "length",
        label: "Length",
        type: FieldType.NUMBER,
        required: false,
        min: 0.01,
        placeholder: "Enter length",
        helpText: "The length of the rectangle",
        unit: "units"
      },
      {
        name: "width",
        label: "Width",
        type: FieldType.NUMBER,
        required: false,
        min: 0.01,
        placeholder: "Enter width",
        helpText: "The width of the rectangle",
        unit: "units"
      },
      {
        name: "radius",
        label: "Radius",
        type: FieldType.NUMBER,
        required: false,
        min: 0.01,
        placeholder: "Enter radius",
        helpText: "The radius of the circle",
        unit: "units"
      },
      {
        name: "base",
        label: "Base",
        type: FieldType.NUMBER,
        required: false,
        min: 0.01,
        placeholder: "Enter base",
        helpText: "The base of the triangle",
        unit: "units"
      },
      {
        name: "height",
        label: "Height",
        type: FieldType.NUMBER,
        required: false,
        min: 0.01,
        placeholder: "Enter height",
        helpText: "The height of the triangle",
        unit: "units"
      }
    ]
  }
];

// Add math calculators to database
export async function addMathCalculators(): Promise<void> {
  for (const calculator of mathCalculators) {
    const existing = await storage.getCalculatorBySlug(calculator.slug);
    if (!existing) {
      await storage.createCalculator(calculator);
    }
  }
}