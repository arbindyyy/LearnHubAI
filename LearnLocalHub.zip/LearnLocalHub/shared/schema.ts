import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema remains the same for preferences and settings
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  preferences: jsonb("preferences").$type<{
    theme: "light" | "dark";
    favoriteCalculators: number[];
    recentCalculators: number[];
  }>(),
  isAdmin: boolean("is_admin").default(false).notNull(),
});

// Calculator categories
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  icon: text("icon"), // Icon name for display
  slug: text("slug").notNull().unique(), // URL-friendly name
  order: integer("order").default(0), // For displaying categories in specific order
});

// Calculator tools
export const calculators = pgTable("calculators", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  slug: text("slug").notNull().unique(), // URL-friendly name
  categoryId: integer("category_id").references(() => categories.id),
  formula: text("formula"), // Mathematical formula text representation
  formulaExplanation: text("formula_explanation"), // Explanation of how the formula works
  icon: text("icon"), // Icon for the calculator
  usage: text("usage"), // How to use this calculator
  examples: jsonb("examples").$type<{
    inputs: Record<string, any>[];
    outputs: any[];
  }>(), // Example calculations
  defaultValues: jsonb("default_values").$type<Record<string, any>>(), // Default input values
  fields: jsonb("fields").$type<Array<{
    name: string;
    label: string;
    type: string;
    required: boolean;
    min?: number;
    max?: number;
    options?: string[];
    placeholder?: string;
    helpText?: string;
    unit?: string;
  }>>(), // Form field definitions
  createdAt: timestamp("created_at").defaultNow().notNull(),
  popularity: integer("popularity").default(0), // Track usage popularity
});

// User calculation history for saved calculations
export const history = pgTable("history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  calculatorId: integer("calculator_id").references(() => calculators.id).notNull(),
  inputs: jsonb("inputs").$type<Record<string, any>>().notNull(), // Input values used
  result: jsonb("result").$type<any>().notNull(), // Calculation result
  notes: text("notes"), // User notes about this calculation
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
});

export const insertCalculatorSchema = createInsertSchema(calculators).omit({
  id: true,
  createdAt: true,
  popularity: true,
});

export const insertHistorySchema = createInsertSchema(history).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

export type InsertCalculator = z.infer<typeof insertCalculatorSchema>;
export type Calculator = typeof calculators.$inferSelect;

export type InsertHistory = z.infer<typeof insertHistorySchema>;
export type History = typeof history.$inferSelect;

// Extended schemas for validation
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// Calculator with category (for joining data)
export type CalculatorWithCategory = Calculator & {
  category?: Category;
};

// Basic calculation input schema for validation
export const calculationSchema = z.object({
  calculatorId: z.number(),
  inputs: z.record(z.any()),
});

// Calculator field types
export enum FieldType {
  NUMBER = 'number',
  TEXT = 'text',
  SELECT = 'select',
  CHECKBOX = 'checkbox',
  RADIO = 'radio',
  DATE = 'date',
  RANGE = 'range',
}

// Theme types
export enum Theme {
  LIGHT = 'light',
  DARK = 'dark',
}
