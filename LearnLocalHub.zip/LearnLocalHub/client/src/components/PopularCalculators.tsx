import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Calculator } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Calculator as CalculatorIcon,
  TrendingUp,
  ArrowRight
} from "lucide-react";

export default function PopularCalculators() {
  // Fetch popular calculators
  const { data: calculators, isLoading, error } = useQuery<Calculator[]>({
    queryKey: ['/api/calculators/popular'],
  });
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <h2 className="text-lg font-semibold">Popular Calculators</h2>
        <div className="space-y-2">
          {[1, 2, 3].map(i => (
            <div key={i} className="flex items-center gap-2 p-2 rounded-md border">
              <Skeleton className="h-8 w-8 rounded-full" />
              <div className="space-y-1 flex-1">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-3/4" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  if (error || !calculators || calculators.length === 0) {
    return null;
  }
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Popular Calculators</h2>
        <TrendingUp className="h-4 w-4 text-muted-foreground" />
      </div>
      
      <div className="space-y-2">
        {calculators.slice(0, 5).map((calculator) => (
          <Link 
            key={calculator.id}
            href={`/calculator/${calculator.slug}`}
            className="flex items-center gap-2 p-2 rounded-md border hover:bg-accent transition-colors group"
          >
            <div className="bg-muted w-8 h-8 rounded-full flex items-center justify-center">
              <CalculatorIcon className="h-4 w-4" />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{calculator.name}</div>
              <div className="text-xs text-muted-foreground truncate">
                {calculator.description.length > 60 
                  ? calculator.description.substring(0, 60) + '...'
                  : calculator.description}
              </div>
            </div>
            
            <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
          </Link>
        ))}
      </div>
    </div>
  );
}