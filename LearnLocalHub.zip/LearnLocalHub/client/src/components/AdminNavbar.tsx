import { Link, useLocation } from "wouter";
import { 
  CalendarPlus, 
  LayoutGrid, 
  Tag, 
  ChevronRight,
  Home
} from "lucide-react";

export default function AdminNavbar() {
  const [location] = useLocation();
  
  const navItems = [
    { path: "/admin", label: "Dashboard", icon: <LayoutGrid className="h-4 w-4" /> },
    { path: "/admin/classes", label: "Classes", icon: <CalendarPlus className="h-4 w-4" /> },
    { path: "/admin/categories", label: "Categories", icon: <Tag className="h-4 w-4" /> }
  ];
  
  return (
    <div className="bg-white border-r border-gray-200 w-64 p-4 h-full shadow-sm">
      <div className="mb-6">
        <Link href="/">
          <a className="flex items-center text-gray-600 hover:text-primary">
            <Home className="h-4 w-4 mr-1" />
            <span className="text-sm">Back to site</span>
          </a>
        </Link>
      </div>
      
      <h2 className="text-xs uppercase font-semibold text-gray-500 tracking-wider mb-3">
        Admin Controls
      </h2>
      
      <ul className="space-y-1">
        {navItems.map((item) => (
          <li key={item.path}>
            <Link href={item.path}>
              <a
                className={`
                  flex items-center text-sm py-2 px-3 rounded-md transition-colors
                  ${location === item.path 
                    ? 'bg-primary/10 text-primary font-medium' 
                    : 'text-gray-700 hover:bg-gray-100'}
                `}
              >
                {item.icon}
                <span className="ml-2">{item.label}</span>
                {location === item.path && <ChevronRight className="h-3 w-3 ml-auto" />}
              </a>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
