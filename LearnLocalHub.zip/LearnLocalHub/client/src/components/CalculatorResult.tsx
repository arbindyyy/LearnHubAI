import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Save, 
  RotateCcw, 
  Calculator, 
  Share, 
  FileText,
  Info
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CalculatorResultProps {
  title: string;
  result: any;
  inputs: Record<string, any>;
  formula?: string;
  onSave?: () => void;
  onReset?: () => void;
}

export default function CalculatorResult({ 
  title, 
  result, 
  inputs, 
  formula,
  onSave,
  onReset 
}: CalculatorResultProps) {
  const [activeTab, setActiveTab] = useState("result");
  const { toast } = useToast();
  
  // Format a single result value
  const formatResultValue = (value: any, key: string) => {
    if (typeof value === 'number') {
      // Try to format numeric values nicely
      return value.toLocaleString(undefined, {
        minimumFractionDigits: value % 1 === 0 ? 0 : 2,
        maximumFractionDigits: 2
      });
    }
    
    if (typeof value === 'boolean') {
      return value ? 'Yes' : 'No';
    }
    
    return value?.toString() || '–';
  };
  
  // Format input value
  const formatInputValue = (value: any, key: string) => {
    if (value === undefined || value === null) {
      return '–';
    }
    
    if (typeof value === 'number') {
      return value.toLocaleString();
    }
    
    if (typeof value === 'boolean') {
      return value ? 'Yes' : 'No';
    }
    
    return value.toString();
  };
  
  // Format key for display
  const formatKey = (key: string) => {
    return key
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, (str) => str.toUpperCase())
      .replace(/([a-z])([A-Z])/g, '$1 $2');
  };
  
  // Handle copy to clipboard
  const handleCopyResults = () => {
    let resultText = `${title} Results:\n\n`;
    
    // Add input parameters
    resultText += "Inputs:\n";
    for (const [key, value] of Object.entries(inputs)) {
      resultText += `${formatKey(key)}: ${formatInputValue(value, key)}\n`;
    }
    
    resultText += "\nResults:\n";
    
    // Handle different result formats
    if (typeof result === 'object' && result !== null) {
      for (const [key, value] of Object.entries(result)) {
        resultText += `${formatKey(key)}: ${formatResultValue(value, key)}\n`;
      }
    } else {
      resultText += formatResultValue(result, 'result');
    }
    
    // Add formula if available
    if (formula) {
      resultText += `\nFormula: ${formula}\n`;
    }
    
    // Add attribution
    resultText += "\nCalculated with Calculator App";
    
    navigator.clipboard.writeText(resultText)
      .then(() => {
        toast({
          title: "Copied to clipboard",
          description: "The calculation results have been copied to your clipboard.",
        });
      })
      .catch((err) => {
        console.error("Could not copy text: ", err);
        toast({
          title: "Copy failed",
          description: "Could not copy to clipboard. Please try again.",
          variant: "destructive",
        });
      });
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-xl font-bold">{title} Results</CardTitle>
            <CardDescription>
              Calculation completed successfully
            </CardDescription>
          </div>
          <Calculator className="h-5 w-5 text-primary" />
        </div>
      </CardHeader>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="px-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="result">Result</TabsTrigger>
            <TabsTrigger value="inputs">Inputs</TabsTrigger>
            {formula && <TabsTrigger value="formula">Formula</TabsTrigger>}
          </TabsList>
        </div>
        
        <TabsContent value="result" className="pt-4">
          <CardContent>
            <div className="space-y-4">
              {typeof result === 'object' && result !== null ? (
                <div className="space-y-3">
                  {Object.entries(result).map(([key, value]) => (
                    <div key={key} className="grid grid-cols-2 gap-2">
                      <div className="text-sm font-medium text-muted-foreground">{formatKey(key)}</div>
                      <div className="text-sm font-semibold">{formatResultValue(value, key)}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4">
                  <div className="text-3xl font-bold text-primary mb-2">
                    {formatResultValue(result, 'result')}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </TabsContent>
        
        <TabsContent value="inputs" className="pt-4">
          <CardContent>
            <div className="space-y-3">
              {Object.entries(inputs).map(([key, value]) => (
                <div key={key} className="grid grid-cols-2 gap-2">
                  <div className="text-sm font-medium text-muted-foreground">{formatKey(key)}</div>
                  <div className="text-sm">{formatInputValue(value, key)}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </TabsContent>
        
        {formula && (
          <TabsContent value="formula" className="pt-4">
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <Info className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    {formula}
                  </div>
                </div>
              </div>
            </CardContent>
          </TabsContent>
        )}
      </Tabs>
      
      <Separator />
      
      <CardFooter className="flex justify-between pt-4">
        <div className="flex gap-2">
          {onReset && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onReset}
            >
              <RotateCcw className="h-4 w-4 mr-1" />
              Reset
            </Button>
          )}
          
          {onSave && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onSave}
            >
              <Save className="h-4 w-4 mr-1" />
              Save
            </Button>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleCopyResults}
          >
            <FileText className="h-4 w-4 mr-1" />
            Copy
          </Button>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => {
              toast({
                title: "Share feature",
                description: "This feature is coming soon.",
              });
            }}
          >
            <Share className="h-4 w-4 mr-1" />
            Share
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}