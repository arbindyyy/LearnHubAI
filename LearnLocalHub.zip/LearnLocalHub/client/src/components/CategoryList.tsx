import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Category } from "@shared/schema";
import { ChevronRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function CategoryList() {
  // Fetch categories
  const { data: categories, isLoading, error } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="flex items-center">
            <Skeleton className="h-4 w-32" />
          </div>
        ))}
      </div>
    );
  }
  
  if (error || !categories) {
    return (
      <div className="text-sm text-muted-foreground">
        Failed to load categories
      </div>
    );
  }
  
  if (categories.length === 0) {
    return (
      <div className="text-sm text-muted-foreground">
        No categories available
      </div>
    );
  }
  
  return (
    <div className="space-y-1">
      {categories.map((category) => (
        <Link 
          key={category.id}
          href={`/category/${category.slug}`}
          className="flex items-center justify-between py-1 px-2 text-sm hover:bg-muted rounded-md text-muted-foreground hover:text-foreground transition-colors"
        >
          <span className="truncate">{category.name}</span>
          <ChevronRight className="h-4 w-4 opacity-60" />
        </Link>
      ))}
    </div>
  );
}