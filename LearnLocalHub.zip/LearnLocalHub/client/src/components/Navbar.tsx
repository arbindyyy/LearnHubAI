import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Calculator, Menu, X } from "lucide-react";
import ThemeToggle from "./ThemeToggle";
import MobileNav from "./MobileNav";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Fetch categories for the navbar
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  return (
    <nav className="border-b">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo & Title */}
          <Link href="/">
            <div className="flex items-center space-x-2 cursor-pointer">
              <Calculator className="h-6 w-6 text-primary" />
              <span className="font-bold text-xl">Calculator App</span>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex md:items-center md:space-x-6">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost">Home</Button>
              </Link>
              
              {categories?.slice(0, 4).map((category) => (
                <Link key={category.id} href={`/category/${category.slug}`}>
                  <Button variant="ghost">{category.name}</Button>
                </Link>
              ))}
            </div>
            
            <div className="flex items-center space-x-2">
              <ThemeToggle />
            </div>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="flex items-center space-x-2 md:hidden">
            <ThemeToggle />
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && <MobileNav onClose={() => setMobileMenuOpen(false)} />}
    </nav>
  );
}