import { useForm, Controller } from "react-hook-form";
import { useEffect, useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calculator as CalculatorType, FieldType } from "@shared/schema";
import { Loader2 } from "lucide-react";

interface CalculatorFormProps {
  calculator: CalculatorType;
  onCalculate: (values: Record<string, any>) => void;
  isCalculating?: boolean;
}

export default function CalculatorForm({ 
  calculator, 
  onCalculate,
  isCalculating = false
}: CalculatorFormProps) {
  const [formSchema, setFormSchema] = useState<z.ZodObject<any>>();
  
  // Dynamically create a zod schema based on the calculator's fields
  useEffect(() => {
    if (!calculator.fields) return;
    
    const schemaObj: Record<string, any> = {};
    
    calculator.fields.forEach(field => {
      // Define the base schema for each field type
      let fieldSchema: z.ZodTypeAny;
      
      switch (field.type) {
        case FieldType.NUMBER:
          fieldSchema = z.number({
            required_error: `${field.label} is required`,
            invalid_type_error: `${field.label} must be a number`,
          });
          
          // Add validation constraints
          if (field.min !== undefined) {
            fieldSchema = fieldSchema.min(field.min, `${field.label} must be at least ${field.min}`);
          }
          if (field.max !== undefined) {
            fieldSchema = fieldSchema.max(field.max, `${field.label} must be at most ${field.max}`);
          }
          break;
          
        case FieldType.TEXT:
          fieldSchema = z.string({
            required_error: `${field.label} is required`,
          });
          
          if (field.minLength) {
            fieldSchema = fieldSchema.min(field.minLength, `${field.label} must be at least ${field.minLength} characters`);
          }
          if (field.maxLength) {
            fieldSchema = fieldSchema.max(field.maxLength, `${field.label} must be at most ${field.maxLength} characters`);
          }
          break;
          
        case FieldType.SELECT:
          fieldSchema = z.string({
            required_error: `Please select a ${field.label.toLowerCase()}`,
          });
          break;
          
        case FieldType.CHECKBOX:
          fieldSchema = z.boolean().default(false);
          break;
          
        case FieldType.RADIO:
          fieldSchema = z.string({
            required_error: `Please select a ${field.label.toLowerCase()}`,
          });
          break;
          
        case FieldType.DATE:
          fieldSchema = z.string({
            required_error: `${field.label} is required`,
          });
          break;
          
        case FieldType.RANGE:
          fieldSchema = z.number({
            required_error: `${field.label} is required`,
            invalid_type_error: `${field.label} must be a number`,
          });
          break;
          
        default:
          fieldSchema = z.string();
      }
      
      // Make the schema optional if not required
      if (!field.required) {
        fieldSchema = fieldSchema.optional();
      }
      
      schemaObj[field.name] = fieldSchema;
    });
    
    setFormSchema(z.object(schemaObj));
  }, [calculator.fields]);
  
  // Create form instance
  const form = useForm<Record<string, any>>({
    resolver: formSchema ? zodResolver(formSchema) : undefined,
    defaultValues: calculator.defaultValues || {},
  });
  
  // Handle form submission
  const onSubmit = (values: Record<string, any>) => {
    onCalculate(values);
  };
  
  if (!calculator.fields || !formSchema) {
    return <div>Loading form...</div>;
  }
  
  // Render dynamic form fields based on the calculator's field definitions
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-4">
          {calculator.fields.map((field) => (
            <FormField
              key={field.name}
              control={form.control}
              name={field.name}
              render={({ field: formField }) => (
                <FormItem>
                  <FormLabel>{field.label}</FormLabel>
                  
                  {/* Render different input types based on field type */}
                  <FormControl>
                    {field.type === FieldType.NUMBER && (
                      <div className="flex items-center space-x-2">
                        <Input
                          type="number"
                          placeholder={field.placeholder}
                          {...formField}
                          onChange={(e) => {
                            const value = e.target.value === '' ? '' : parseFloat(e.target.value);
                            formField.onChange(value);
                          }}
                        />
                        {field.unit && (
                          <span className="text-sm text-muted-foreground">{field.unit}</span>
                        )}
                      </div>
                    )}
                    
                    {field.type === FieldType.TEXT && (
                      <Input
                        type="text"
                        placeholder={field.placeholder}
                        {...formField}
                      />
                    )}
                    
                    {field.type === FieldType.SELECT && field.options && (
                      <Select
                        value={formField.value}
                        onValueChange={formField.onChange}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={field.placeholder || `Select ${field.label}`} />
                        </SelectTrigger>
                        <SelectContent>
                          {field.options.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                    
                    {field.type === FieldType.RADIO && field.options && (
                      <RadioGroup
                        value={formField.value}
                        onValueChange={formField.onChange}
                        className="flex flex-col space-y-1"
                      >
                        {field.options.map((option) => (
                          <div key={option} className="flex items-center space-x-2">
                            <RadioGroupItem value={option} id={`${field.name}-${option}`} />
                            <label htmlFor={`${field.name}-${option}`} className="text-sm">
                              {option}
                            </label>
                          </div>
                        ))}
                      </RadioGroup>
                    )}
                    
                    {field.type === FieldType.CHECKBOX && (
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          checked={formField.value}
                          onCheckedChange={formField.onChange}
                          id={field.name}
                        />
                        <label
                          htmlFor={field.name}
                          className="text-sm font-normal leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {field.placeholder || `Enable ${field.label}`}
                        </label>
                      </div>
                    )}
                    
                    {field.type === FieldType.DATE && (
                      <Input
                        type="date"
                        placeholder={field.placeholder}
                        {...formField}
                      />
                    )}
                    
                    {field.type === FieldType.RANGE && field.min !== undefined && field.max !== undefined && (
                      <div className="space-y-2">
                        <Controller
                          control={form.control}
                          name={field.name}
                          render={({ field: controllerField }) => (
                            <>
                              <Slider
                                defaultValue={[controllerField.value || field.min]}
                                min={field.min}
                                max={field.max}
                                step={field.step || 1}
                                onValueChange={(values) => controllerField.onChange(values[0])}
                              />
                              <div className="flex justify-between text-xs text-muted-foreground">
                                <span>{field.min}{field.unit}</span>
                                <span className="font-medium">
                                  {controllerField.value || field.min}
                                  {field.unit}
                                </span>
                                <span>{field.max}{field.unit}</span>
                              </div>
                            </>
                          )}
                        />
                      </div>
                    )}
                  </FormControl>
                  
                  {field.helpText && (
                    <FormDescription>{field.helpText}</FormDescription>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
        </div>
        
        <Button type="submit" disabled={isCalculating} className="w-full">
          {isCalculating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Calculating...
            </>
          ) : (
            'Calculate'
          )}
        </Button>
      </form>
    </Form>
  );
}