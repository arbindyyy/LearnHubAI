import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Clock, Users } from "lucide-react";
import { type Class } from "@shared/schema";
import { format } from "date-fns";

interface ClassCardProps {
  classItem: Class;
  categoryName?: string;
}

export default function ClassCard({ classItem, categoryName }: ClassCardProps) {
  return (
    <Card className="h-full flex flex-col hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{classItem.title}</CardTitle>
          {categoryName && (
            <Badge variant="secondary" className="ml-2 mt-1">
              {categoryName}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-gray-600 line-clamp-3 mb-4">
          {classItem.description}
        </p>
        
        <div className="space-y-2">
          <div className="flex items-center text-sm">
            <MapPin className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-gray-700">{classItem.location}</span>
          </div>
          
          <div className="flex items-center text-sm">
            <Users className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-gray-700">
              {classItem.currentEnrollment}/{classItem.maxCapacity} enrolled
            </span>
          </div>
          
          <div className="flex items-center text-sm">
            <Calendar className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-gray-700">
              {format(new Date(classItem.createdAt), "MMM d, yyyy")}
            </span>
          </div>
          
          {classItem.price && (
            <div className="text-sm font-medium">
              Price: {classItem.price}
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="pt-2 border-t">
        <Link href={`/classes/${classItem.id}`}>
          <Button variant="outline" className="w-full">
            View Details
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
