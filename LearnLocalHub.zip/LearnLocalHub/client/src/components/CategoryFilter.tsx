import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { type Category } from "@shared/schema";

interface CategoryFilterProps {
  selectedCategoryId: number | null;
  onSelectCategory: (categoryId: number | null) => void;
}

export default function CategoryFilter({ 
  selectedCategoryId, 
  onSelectCategory 
}: CategoryFilterProps) {
  const { data: categories, isLoading, error } = useQuery<Category[]>({
    queryKey: ['/api/categories']
  });
  
  // Reset the filter if the selected category doesn't exist
  useEffect(() => {
    if (categories && selectedCategoryId) {
      const categoryExists = categories.some(category => category.id === selectedCategoryId);
      if (!categoryExists) {
        onSelectCategory(null);
      }
    }
  }, [categories, selectedCategoryId, onSelectCategory]);

  if (isLoading) {
    return (
      <div className="flex flex-wrap gap-2 mb-6">
        {[1, 2, 3, 4].map(i => (
          <Skeleton key={i} className="h-6 w-20 rounded-full" />
        ))}
      </div>
    );
  }
  
  if (error || !categories) {
    return <div className="text-sm text-red-500">Failed to load categories</div>;
  }
  
  return (
    <div className="mb-6">
      <h3 className="text-sm font-medium text-gray-700 mb-2">Filter by category:</h3>
      <div className="flex flex-wrap gap-2">
        <Badge 
          variant={selectedCategoryId === null ? "default" : "outline"} 
          className="cursor-pointer"
          onClick={() => onSelectCategory(null)}
        >
          All Categories
        </Badge>
        
        {categories.map(category => (
          <Badge
            key={category.id}
            variant={selectedCategoryId === category.id ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => onSelectCategory(category.id)}
          >
            {category.name}
          </Badge>
        ))}
      </div>
    </div>
  );
}
