import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calculator as CalculatorType } from "@shared/schema";
import { 
  Calculator,
  ArrowRight,
  TrendingUp,
  Percent,
  DollarSign,
  Heart,
  Clock,
  Ruler,
  BarChart4,
  Building2,
  Shapes,
  Activity,
  Thermometer,
  Scale,
  Dumbbell
} from "lucide-react";

interface CalculatorCardProps {
  calculator: CalculatorType;
  categoryName?: string;
}

export default function CalculatorCard({ calculator, categoryName }: CalculatorCardProps) {
  // Get icon based on calculator type or category
  const getIcon = () => {
    // Check if calculator has its own icon
    if (calculator.icon) {
      return <Calculator className="h-5 w-5" />;
    }
    
    // Try to determine icon from category or calculator name
    const name = calculator.name.toLowerCase();
    
    if (name.includes('loan') || name.includes('emi') || name.includes('mortgage')) {
      return <DollarSign className="h-5 w-5" />;
    }
    
    if (name.includes('interest') || name.includes('return') || name.includes('investment')) {
      return <TrendingUp className="h-5 w-5" />;
    }
    
    if (name.includes('percentage') || name.includes('ratio') || name.includes('tax')) {
      return <Percentage className="h-5 w-5" />;
    }
    
    if (name.includes('bmi') || name.includes('health') || name.includes('weight')) {
      return <Heart className="h-5 w-5" />;
    }
    
    if (name.includes('age') || name.includes('date') || name.includes('time')) {
      return <Clock className="h-5 w-5" />;
    }
    
    if (name.includes('length') || name.includes('area') || name.includes('distance')) {
      return <Ruler className="h-5 w-5" />;
    }
    
    if (name.includes('stat') || name.includes('average') || name.includes('mean')) {
      return <BarChart4 className="h-5 w-5" />;
    }
    
    if (name.includes('construction') || name.includes('building')) {
      return <Building2 className="h-5 w-5" />;
    }
    
    if (name.includes('shape') || name.includes('volume') || name.includes('dimension')) {
      return <Shapes className="h-5 w-5" />;
    }
    
    if (name.includes('heart') || name.includes('pulse') || name.includes('blood')) {
      return <Activity className="h-5 w-5" />;
    }
    
    if (name.includes('temperature') || name.includes('celsius') || name.includes('fahrenheit')) {
      return <Thermometer className="h-5 w-5" />;
    }
    
    if (name.includes('mass') || name.includes('weight') || name.includes('conversion')) {
      return <Scale className="h-5 w-5" />;
    }
    
    if (name.includes('fitness') || name.includes('calorie') || name.includes('exercise')) {
      return <Dumbbell className="h-5 w-5" />;
    }
    
    // Default icon
    return <Calculator className="h-5 w-5" />;
  };
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow flex flex-col h-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex-1 mr-2">
            <CardTitle className="text-base flex gap-2 items-center">
              {getIcon()}
              <span className="line-clamp-1">{calculator.name}</span>
            </CardTitle>
            {categoryName && (
              <Badge variant="outline" className="mt-1.5 font-normal text-xs">
                {categoryName}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="py-2 flex-grow">
        <p className="text-sm text-muted-foreground line-clamp-3">
          {calculator.description}
        </p>
      </CardContent>
      
      <CardFooter className="pt-2">
        <Link href={`/calculator/${calculator.slug}`} className="w-full">
          <Button 
            variant="default" 
            className="w-full"
            size="sm"
          >
            Use Calculator
            <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}