import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock } from "lucide-react";
import { format } from "date-fns";
import { type Session } from "@shared/schema";

interface AvailabilityDisplayProps {
  sessions: Session[];
}

export default function AvailabilityDisplay({ sessions }: AvailabilityDisplayProps) {
  if (!sessions.length) {
    return (
      <div className="text-center p-6 bg-gray-50 rounded-md">
        <Calendar className="h-8 w-8 text-gray-400 mx-auto mb-2" />
        <p className="text-gray-500">No sessions scheduled for this class yet.</p>
      </div>
    );
  }

  // Sort sessions by start time
  const sortedSessions = [...sessions].sort((a, b) => 
    new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
  );
  
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Time</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedSessions.map((session) => (
            <TableRow key={session.id}>
              <TableCell>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                  {format(new Date(session.startTime), "EEEE, MMM d, yyyy")}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-500" />
                  {format(new Date(session.startTime), "h:mm a")} - {format(new Date(session.endTime), "h:mm a")}
                </div>
              </TableCell>
              <TableCell>
                <Badge variant={session.isAvailable ? "success" : "destructive"}>
                  {session.isAvailable ? "Available" : "Full"}
                </Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
