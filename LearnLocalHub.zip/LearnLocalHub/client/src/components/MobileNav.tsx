import { Link } from "wouter";
import { Calculator, GridIcon, BookOpen, Search, User } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";

interface MobileNavProps {
  onClose: () => void;
}

export default function MobileNav({ onClose }: MobileNavProps) {
  // Fetch categories for the menu
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  return (
    <div className="fixed inset-0 z-50 bg-background pt-16 pb-20">
      <div className="container h-full overflow-y-auto p-4">
        <nav className="space-y-8">
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">Main Navigation</h3>
            <div className="grid grid-cols-2 gap-2">
              <Link href="/" onClick={onClose}>
                <div className="flex items-center space-x-2 rounded-md border p-2 hover:bg-accent">
                  <GridIcon className="h-4 w-4" />
                  <span className="text-sm font-medium">All Calculators</span>
                </div>
              </Link>
              
              <Link href="/popular" onClick={onClose}>
                <div className="flex items-center space-x-2 rounded-md border p-2 hover:bg-accent">
                  <Calculator className="h-4 w-4" />
                  <span className="text-sm font-medium">Popular</span>
                </div>
              </Link>
              
              <Link href="/search" onClick={onClose}>
                <div className="flex items-center space-x-2 rounded-md border p-2 hover:bg-accent">
                  <Search className="h-4 w-4" />
                  <span className="text-sm font-medium">Search</span>
                </div>
              </Link>
              
              <Link href="/help" onClick={onClose}>
                <div className="flex items-center space-x-2 rounded-md border p-2 hover:bg-accent">
                  <BookOpen className="h-4 w-4" />
                  <span className="text-sm font-medium">Help</span>
                </div>
              </Link>
            </div>
          </div>
          
          {categories && categories.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Categories</h3>
              <div className="grid grid-cols-1 gap-1">
                {categories.map((category) => (
                  <Link
                    key={category.id}
                    href={`/category/${category.slug}`}
                    onClick={onClose}
                  >
                    <div className="flex items-center space-x-2 rounded-md px-2 py-1.5 hover:bg-accent">
                      <span className="text-sm">{category.name}</span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
          
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">Account</h3>
            <div className="grid grid-cols-1 gap-1">
              <Link href="/login" onClick={onClose}>
                <div className="flex items-center space-x-2 rounded-md px-2 py-1.5 hover:bg-accent">
                  <User className="h-4 w-4" />
                  <span className="text-sm">Login</span>
                </div>
              </Link>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
}