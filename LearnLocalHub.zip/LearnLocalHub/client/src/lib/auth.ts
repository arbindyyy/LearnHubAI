import { apiRequest } from "./queryClient";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "./queryClient";

export type UserInfo = {
  id: number;
  username: string;
  isAdmin: boolean;
  preferences?: {
    theme: "light" | "dark";
    favoriteCalculators: number[];
    recentCalculators: number[];
  } | null;
};

// Login function
export async function login(username: string, password: string): Promise<UserInfo> {
  const response = await apiRequest("POST", "/api/login", { username, password });
  return response.json();
}

// Logout function
export async function logout(): Promise<void> {
  await apiRequest("POST", "/api/logout");
}

// Get current user function
export async function getCurrentUser(): Promise<UserInfo | null> {
  try {
    const response = await fetch("/api/me", {
      credentials: "include",
    });
    
    if (response.status === 401) {
      return null;
    }
    
    if (!response.ok) {
      throw new Error("Failed to fetch user");
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error fetching current user:", error);
    return null;
  }
}

// Hook to get current user
export function useCurrentUser() {
  return useQuery({ 
    queryKey: ["/api/me"],
    queryFn: getCurrentUser,
    // On 401, return null instead of throwing
    retry: false,
    refetchOnWindowFocus: true,
  });
}

// Hook for login mutation
export function useLogin() {
  return useMutation({
    mutationFn: ({ username, password }: { username: string; password: string }) => 
      login(username, password),
    onSuccess: () => {
      // Invalidate the current user query to refetch after login
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
    }
  });
}

// Hook for logout mutation
export function useLogout() {
  return useMutation({
    mutationFn: logout,
    onSuccess: () => {
      // Invalidate the current user query to refetch after logout
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
    }
  });
}

// Function to check if user is admin
export function isAdmin(user: UserInfo | null | undefined): boolean {
  return Boolean(user?.isAdmin);
}

// Function to get user preferences
export function getUserPreference(user: UserInfo | null | undefined, key: string, defaultValue: any = null): any {
  if (!user?.preferences) return defaultValue;
  return (user.preferences as any)[key] ?? defaultValue;
}

// Function to update user preferences
export async function updateUserPreferences(preferences: Partial<UserInfo['preferences']>): Promise<void> {
  await apiRequest("PUT", "/api/user/preferences", preferences);
  queryClient.invalidateQueries({ queryKey: ["/api/me"] });
}
