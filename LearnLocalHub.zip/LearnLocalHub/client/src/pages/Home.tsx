import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Calculator, Category } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Grid3X3, ListFilter } from "lucide-react";
import CategoryList from "@/components/CategoryList";
import PopularCalculators from "@/components/PopularCalculators";
import CalculatorCard from "@/components/CalculatorCard";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  
  // Fetch calculators
  const { data: calculators, isLoading: calculatorsLoading } = useQuery<Calculator[]>({
    queryKey: ['/api/calculators'],
  });
  
  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  // Filter calculators based on search query and selected category
  const filteredCalculators = calculators?.filter(calculator => {
    // Filter by category if one is selected
    if (selectedCategoryId !== null && calculator.categoryId !== selectedCategoryId) {
      return false;
    }
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        calculator.name.toLowerCase().includes(query) || 
        calculator.description.toLowerCase().includes(query)
      );
    }
    
    return true;
  });
  
  // Get category name by id
  const getCategoryName = (categoryId: number | null) => {
    if (!categoryId || !categories) return null;
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : null;
  };
  
  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };
  
  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Left sidebar */}
        <div className="md:w-64 flex-shrink-0 space-y-8">
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Categories</h2>
            <CategoryList />
          </div>
          
          <PopularCalculators />
        </div>
        
        {/* Main content */}
        <div className="flex-1 space-y-6">
          {/* Search and filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <form onSubmit={handleSearch} className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search calculators..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>
            
            <div className="flex gap-2">
              <Button
                variant={selectedCategoryId ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategoryId(null)}
                className="hidden sm:flex"
              >
                All
              </Button>
              
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="icon"
                onClick={() => setViewMode("grid")}
                aria-label="Grid view"
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              
              <Button
                variant={viewMode === "list" ? "default" : "outline"}
                size="icon"
                onClick={() => setViewMode("list")}
                aria-label="List view"
              >
                <ListFilter className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Category tabs (mobile only) */}
          <div className="block sm:hidden">
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="mb-4 w-full overflow-auto">
                <TabsTrigger 
                  value="all" 
                  onClick={() => setSelectedCategoryId(null)}
                  className="flex-shrink-0"
                >
                  All
                </TabsTrigger>
                {categories?.map((category) => (
                  <TabsTrigger
                    key={category.id}
                    value={category.id.toString()}
                    onClick={() => setSelectedCategoryId(category.id)}
                    className="flex-shrink-0"
                  >
                    {category.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
          
          {/* Calculators grid/list */}
          <div>
            <h1 className="text-2xl font-bold mb-6">
              {selectedCategoryId
                ? `${getCategoryName(selectedCategoryId)} Calculators`
                : searchQuery
                  ? "Search Results"
                  : "All Calculators"}
            </h1>
            
            {calculatorsLoading ? (
              <div className={`grid grid-cols-1 ${viewMode === "grid" ? "sm:grid-cols-2 lg:grid-cols-3" : ""} gap-4`}>
                {Array.from({ length: 6 }).map((_, index) => (
                  <div key={index} className="border rounded-lg p-4 h-64">
                    <div className="flex justify-between">
                      <Skeleton className="h-6 w-32 mb-2" />
                      <Skeleton className="h-6 w-6 rounded-full" />
                    </div>
                    <Skeleton className="h-4 w-16 mb-4" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-3/4 mb-8" />
                    <Skeleton className="h-10 w-full rounded-md" />
                  </div>
                ))}
              </div>
            ) : filteredCalculators && filteredCalculators.length > 0 ? (
              <div className={`grid grid-cols-1 ${viewMode === "grid" ? "sm:grid-cols-2 lg:grid-cols-3" : ""} gap-4`}>
                {filteredCalculators.map((calculator) => (
                  <CalculatorCard
                    key={calculator.id}
                    calculator={calculator}
                    categoryName={
                      viewMode === "grid" 
                        ? selectedCategoryId ? undefined : getCategoryName(calculator.categoryId)
                        : getCategoryName(calculator.categoryId)
                    }
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <h3 className="text-lg font-medium mb-2">No calculators found</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {searchQuery
                    ? `No results found for "${searchQuery}"`
                    : "No calculators available in this category"}
                </p>
                {searchQuery && (
                  <Button variant="outline" onClick={() => setSearchQuery("")}>
                    Clear search
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}