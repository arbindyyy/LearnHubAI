import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useCurrentUser, isAdmin } from "@/lib/auth";
import Navbar from "@/components/Navbar";
import AdminNavbar from "@/components/AdminNavbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BookOpen, 
  Tag, 
  CalendarDays, 
  Users, 
  PlusCircle, 
  Layers, 
  AlertTriangle
} from "lucide-react";
import { type Class, type Category } from "@shared/schema";

export default function Admin() {
  const [location, navigate] = useLocation();
  const { data: user, isLoading: userLoading } = useCurrentUser();
  
  const { data: classes = [] } = useQuery<Class[]>({
    queryKey: ['/api/classes'],
    enabled: isAdmin(user)
  });
  
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    enabled: isAdmin(user)
  });
  
  // Redirect if not admin
  useEffect(() => {
    if (!userLoading && !isAdmin(user)) {
      navigate("/login");
    }
  }, [user, userLoading, navigate]);
  
  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex justify-center items-center h-[calc(100vh-64px)]">
          <div className="animate-pulse text-gray-500">Loading...</div>
        </div>
      </div>
    );
  }
  
  if (!isAdmin(user)) {
    return null; // Redirecting in useEffect
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="flex h-[calc(100vh-64px)]">
        <AdminNavbar />
        
        <main className="flex-1 p-6 overflow-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-600">Manage your community classes and workshops</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">Classes</CardTitle>
                <BookOpen className="h-5 w-5 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{classes.length}</div>
                <p className="text-xs text-gray-500 mt-1">Total classes</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full mt-4"
                  onClick={() => navigate("/admin/classes")}
                >
                  <Layers className="h-4 w-4 mr-1" />
                  Manage Classes
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">Categories</CardTitle>
                <Tag className="h-5 w-5 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{categories.length}</div>
                <p className="text-xs text-gray-500 mt-1">Total categories</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full mt-4"
                  onClick={() => navigate("/admin/categories")}
                >
                  <Layers className="h-4 w-4 mr-1" />
                  Manage Categories
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">Quick Actions</CardTitle>
                <CalendarDays className="h-5 w-5 text-primary" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  variant="default" 
                  size="sm" 
                  className="w-full"
                  onClick={() => navigate("/admin/classes/new")}
                >
                  <PlusCircle className="h-4 w-4 mr-1" />
                  Add New Class
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={() => navigate("/")}
                >
                  <Users className="h-4 w-4 mr-1" />
                  View Public Site
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Admin Guide</CardTitle>
              <CardDescription>Quick tips to manage your community classes platform</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="bg-blue-100 p-2 rounded-full h-fit">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Managing Classes</h3>
                  <p className="text-sm text-gray-600">
                    Add, edit, or remove classes from the Classes section. Make sure to include 
                    session times and availability information.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-2">
                <div className="bg-blue-100 p-2 rounded-full h-fit">
                  <Tag className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Managing Categories</h3>
                  <p className="text-sm text-gray-600">
                    Organize your classes by creating and managing categories. 
                    Categories help users filter and find relevant classes.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-2">
                <div className="bg-amber-100 p-2 rounded-full h-fit">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Important Notes</h3>
                  <p className="text-sm text-gray-600">
                    This admin panel gives you full control over your site's content.
                    Be careful when deleting items, as this action cannot be undone.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
