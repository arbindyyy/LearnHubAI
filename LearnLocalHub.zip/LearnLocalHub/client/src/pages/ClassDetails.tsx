import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import AvailabilityDisplay from "@/components/AvailabilityDisplay";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  CalendarPlus,
  MapPin,
  Users,
  User,
  Mail,
  Phone,
  ChevronLeft,
  AlertCircle
} from "lucide-react";
import { type ClassWithSessions } from "@shared/schema";

export default function ClassDetails() {
  const { id } = useParams<{ id: string }>();
  const numId = parseInt(id);
  
  const { data: classDetails, isLoading, error } = useQuery<ClassWithSessions>({
    queryKey: [`/api/classes/${numId}`],
    enabled: !isNaN(numId),
  });
  
  if (isNaN(numId)) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-12">
          <div className="bg-red-50 p-6 rounded-lg text-center">
            <AlertCircle className="h-10 w-10 text-red-400 mx-auto mb-2" />
            <h3 className="text-lg font-medium text-red-800 mb-1">Invalid Class ID</h3>
            <Link href="/">
              <Button variant="outline" className="mt-4">
                <ChevronLeft className="h-4 w-4 mr-1" /> Return to Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Skeleton className="h-8 w-64" />
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <Skeleton className="h-10 w-2/3 mb-4" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-3/4 mb-6" />
                
                <Skeleton className="h-6 w-32 mb-3" />
                <Skeleton className="h-24 w-full" />
              </div>
              <div>
                <Skeleton className="h-6 w-32 mb-3" />
                <Skeleton className="h-32 w-full mb-6" />
                
                <Skeleton className="h-6 w-32 mb-3" />
                <Skeleton className="h-24 w-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !classDetails) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-12">
          <div className="bg-red-50 p-6 rounded-lg text-center">
            <AlertCircle className="h-10 w-10 text-red-400 mx-auto mb-2" />
            <h3 className="text-lg font-medium text-red-800 mb-1">Class Not Found</h3>
            <p className="text-red-600 mb-4">The class you're looking for doesn't exist or has been removed.</p>
            <Link href="/">
              <Button variant="outline">
                <ChevronLeft className="h-4 w-4 mr-1" /> Return to Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/">
            <a className="inline-flex items-center text-sm text-primary hover:underline">
              <ChevronLeft className="h-4 w-4 mr-1" /> Back to all classes
            </a>
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 mb-6">
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">{classDetails.title}</h1>
            
            {classDetails.category && (
              <Badge className="text-sm" variant="secondary">
                {classDetails.category.name}
              </Badge>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <h2 className="text-xl font-semibold text-gray-800 mb-3">About This Class</h2>
              <p className="text-gray-700 whitespace-pre-line mb-8">
                {classDetails.description}
              </p>
              
              <h2 className="text-xl font-semibold text-gray-800 mb-3">Class Schedule</h2>
              <AvailabilityDisplay sessions={classDetails.sessions} />
            </div>
            
            <div>
              <div className="bg-gray-50 p-5 rounded-lg mb-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Class Details</h2>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-primary mt-0.5 mr-3" />
                    <div>
                      <h3 className="font-medium text-gray-700">Location</h3>
                      <p className="text-gray-600">{classDetails.location}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <User className="h-5 w-5 text-primary mt-0.5 mr-3" />
                    <div>
                      <h3 className="font-medium text-gray-700">Instructor</h3>
                      <p className="text-gray-600">{classDetails.instructor}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Users className="h-5 w-5 text-primary mt-0.5 mr-3" />
                    <div>
                      <h3 className="font-medium text-gray-700">Capacity</h3>
                      <p className="text-gray-600">
                        {classDetails.currentEnrollment}/{classDetails.maxCapacity} enrolled
                      </p>
                    </div>
                  </div>
                  
                  {classDetails.price && (
                    <div className="flex items-start">
                      <div className="h-5 w-5 flex items-center justify-center text-primary mt-0.5 mr-3">
                        $
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-700">Price</h3>
                        <p className="text-gray-600">{classDetails.price}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="bg-gray-50 p-5 rounded-lg">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Contact Information</h2>
                
                <div className="space-y-4">
                  {classDetails.contactEmail && (
                    <div className="flex items-start">
                      <Mail className="h-5 w-5 text-primary mt-0.5 mr-3" />
                      <div>
                        <h3 className="font-medium text-gray-700">Email</h3>
                        <a href={`mailto:${classDetails.contactEmail}`} className="text-primary hover:underline">
                          {classDetails.contactEmail}
                        </a>
                      </div>
                    </div>
                  )}
                  
                  {classDetails.contactPhone && (
                    <div className="flex items-start">
                      <Phone className="h-5 w-5 text-primary mt-0.5 mr-3" />
                      <div>
                        <h3 className="font-medium text-gray-700">Phone</h3>
                        <a href={`tel:${classDetails.contactPhone}`} className="text-primary hover:underline">
                          {classDetails.contactPhone}
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
