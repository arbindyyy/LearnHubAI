import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Calculator as CalculatorType, Category } from "@shared/schema";
import { 
  Calculator, 
  ArrowLeft,
  BookOpen,
  Share,
  Save,
  Star,
  List
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import CalculatorForm from "@/components/CalculatorForm";
import CalculatorResult from "@/components/CalculatorResult";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function CalculatorPage() {
  const [match, params] = useRoute("/calculator/:slug");
  const slug = params?.slug;
  const { toast } = useToast();
  
  const [isCalculating, setIsCalculating] = useState(false);
  const [calculationResult, setCalculationResult] = useState<any>(null);
  const [calculationInputs, setCalculationInputs] = useState<Record<string, any>>({});
  
  // Fetch calculator data
  const { data: calculator, isLoading: calculatorLoading } = useQuery<CalculatorType>({
    queryKey: ['/api/calculator', slug],
    enabled: !!slug,
  });
  
  // Fetch categories for breadcrumb
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  // Get category name
  const getCategoryName = (categoryId: number | null) => {
    if (!categoryId || !categories) return null;
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : null;
  };
  
  // Handle calculation
  const handleCalculate = async (values: Record<string, any>) => {
    if (!calculator) return;
    
    setIsCalculating(true);
    setCalculationInputs(values);
    
    try {
      // Call the API to perform the calculation
      const data = await apiRequest({
        url: `/api/calculate/${calculator.id}`,
        method: 'POST',
        data: { inputs: values }
      });
      
      setCalculationResult(data);
    } catch (error) {
      console.error('Calculation error:', error);
      toast({
        title: "Calculation Error",
        description: "There was an error performing the calculation. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };
  
  // Handle reset
  const handleReset = () => {
    setCalculationResult(null);
    setCalculationInputs({});
  };
  
  // Handle saving calculation
  const handleSaveCalculation = async () => {
    if (!calculator || !calculationResult) return;
    
    try {
      await apiRequest({
        url: `/api/history`,
        method: 'POST',
        data: {
          calculatorId: calculator.id,
          inputs: calculationInputs,
          result: calculationResult
        }
      });
      
      toast({
        title: "Calculation Saved",
        description: "This calculation has been saved to your history.",
      });
    } catch (error) {
      console.error('Save error:', error);
      toast({
        title: "Save Error",
        description: "There was an error saving your calculation. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  if (!match) {
    return (
      <div className="container mx-auto p-4 md:p-6">
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold mb-2">Calculator Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The calculator you're looking for doesn't exist or has been moved.
          </p>
          <Link href="/">
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to All Calculators
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto p-4 md:p-6">
      {/* Breadcrumb */}
      <div className="flex items-center mb-6 text-sm text-muted-foreground">
        <Link href="/">
          <span className="hover:text-foreground cursor-pointer">Home</span>
        </Link>
        <span className="mx-2">/</span>
        {calculator && calculator.categoryId && (
          <>
            <Link href={`/category/${calculator.categoryId}`}>
              <span className="hover:text-foreground cursor-pointer">
                {getCategoryName(calculator.categoryId)}
              </span>
            </Link>
            <span className="mx-2">/</span>
          </>
        )}
        <span className="text-foreground font-medium">
          {calculatorLoading ? <Skeleton className="w-32 h-4" /> : calculator?.name}
        </span>
      </div>
      
      {calculatorLoading ? (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-10 w-28" />
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <Skeleton className="h-96 rounded-lg" />
            <Skeleton className="h-96 rounded-lg" />
          </div>
        </div>
      ) : calculator ? (
        <>
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">{calculator.name}</h1>
              <p className="text-muted-foreground max-w-2xl mt-1">{calculator.description}</p>
            </div>
            
            <div className="flex gap-2 flex-shrink-0">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  toast({
                    title: "Feature Coming Soon",
                    description: "This feature will be available in a future update.",
                  });
                }}
              >
                <Star className="h-4 w-4 mr-1" />
                Save
              </Button>
              <Link href="/">
                <Button variant="default" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Back
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Main content */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Calculator form */}
            <div>
              <Card>
                <CardContent className="pt-6">
                  <CalculatorForm 
                    calculator={calculator} 
                    onCalculate={handleCalculate}
                    isCalculating={isCalculating}
                  />
                </CardContent>
              </Card>
            </div>
            
            {/* Results or info */}
            <div>
              {calculationResult ? (
                <CalculatorResult 
                  title={calculator.name}
                  result={calculationResult}
                  inputs={calculationInputs}
                  formula={calculator.formula || undefined}
                  onSave={handleSaveCalculation}
                  onReset={handleReset}
                />
              ) : (
                <Card>
                  <Tabs defaultValue="info" className="w-full">
                    <TabsList className="w-full grid grid-cols-3">
                      <TabsTrigger value="info">
                        <BookOpen className="h-4 w-4 mr-2" />
                        Info
                      </TabsTrigger>
                      <TabsTrigger value="usage">
                        <List className="h-4 w-4 mr-2" />
                        Usage
                      </TabsTrigger>
                      <TabsTrigger value="formula">
                        <Calculator className="h-4 w-4 mr-2" />
                        Formula
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="info" className="space-y-4 p-6">
                      <h3 className="text-lg font-semibold">About this calculator</h3>
                      <p className="text-muted-foreground">{calculator.description}</p>
                      <Separator />
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium">Category</h4>
                          <p className="text-sm text-muted-foreground">
                            {getCategoryName(calculator.categoryId)}
                          </p>
                        </div>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="usage" className="space-y-4 p-6">
                      <h3 className="text-lg font-semibold">How to use</h3>
                      <p className="text-muted-foreground">
                        {calculator.usage || "Fill in the required fields on the left and click calculate to see the results."}
                      </p>
                      
                      {calculator.examples && (
                        <>
                          <Separator />
                          <div>
                            <h4 className="font-medium mb-2">Example</h4>
                            <div className="space-y-1">
                              <p className="text-sm text-muted-foreground">Input values:</p>
                              <ul className="list-disc pl-5 text-sm">
                                {calculator.examples.inputs && calculator.examples.inputs.length > 0 && 
                                  Object.entries(calculator.examples.inputs[0]).map(([key, value]) => (
                                    <li key={key}>
                                      <span className="font-medium">{key}:</span>{" "}
                                      {typeof value === "object" ? JSON.stringify(value) : String(value)}
                                    </li>
                                  ))
                                }
                              </ul>
                            </div>
                          </div>
                        </>
                      )}
                    </TabsContent>
                    
                    <TabsContent value="formula" className="space-y-4 p-6">
                      <h3 className="text-lg font-semibold">Formula</h3>
                      <div className="p-3 bg-muted rounded-md font-mono text-sm">
                        {calculator.formula || "Custom calculation logic"}
                      </div>
                      
                      {calculator.formulaExplanation && (
                        <>
                          <h4 className="font-medium">Explanation</h4>
                          <p className="text-sm text-muted-foreground">
                            {calculator.formulaExplanation}
                          </p>
                        </>
                      )}
                    </TabsContent>
                  </Tabs>
                </Card>
              )}
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold mb-2">Calculator Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The calculator you're looking for doesn't exist or has been moved.
          </p>
          <Link href="/">
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to All Calculators
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}