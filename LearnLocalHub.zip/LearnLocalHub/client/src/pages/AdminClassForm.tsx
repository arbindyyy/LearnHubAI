import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useCurrentUser, isAdmin } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import Navbar from "@/components/Navbar";
import AdminNavbar from "@/components/AdminNavbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { CalendarIcon, PlusCircle, Trash, CalendarPlus, CalendarCheck, Save, ArrowLeft } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { insertClassSchema, insertSessionSchema, type Class, type Category, type Session } from "@shared/schema";

// Combined schema for sessions with class
const classFormSchema = insertClassSchema.extend({
  sessions: z.array(
    z.object({
      startDate: z.date(),
      startTime: z.string(),
      endTime: z.string(),
      isAvailable: z.boolean().default(true),
    })
  ).optional(),
});

type ClassFormValues = z.infer<typeof classFormSchema>;

export default function AdminClassForm() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { data: user, isLoading: userLoading } = useCurrentUser();
  const [sessions, setSessions] = useState<Array<{ id?: number, startDate: Date, startTime: string, endTime: string, isAvailable: boolean }>>([]);
  
  // Fetch categories for select dropdown
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    enabled: isAdmin(user)
  });
  
  // Fetch class data if editing
  const { data: classData, isLoading: classLoading } = useQuery<Class & { sessions: Session[] }>({
    queryKey: [`/api/classes/${id}`],
    enabled: !!id && isAdmin(user),
  });
  
  // Initialize form with data if editing
  const form = useForm<ClassFormValues>({
    resolver: zodResolver(classFormSchema),
    defaultValues: {
      title: "",
      description: "",
      location: "",
      instructor: "",
      price: "",
      maxCapacity: 10,
      categoryId: undefined,
      contactEmail: "",
      contactPhone: "",
    },
  });
  
  // Set form values when class data is loaded
  useEffect(() => {
    if (classData) {
      form.reset({
        title: classData.title,
        description: classData.description,
        location: classData.location,
        instructor: classData.instructor,
        price: classData.price || "",
        maxCapacity: classData.maxCapacity,
        categoryId: classData.categoryId,
        contactEmail: classData.contactEmail || "",
        contactPhone: classData.contactPhone || "",
      });
      
      // Set sessions
      if (classData.sessions) {
        const formattedSessions = classData.sessions.map(session => ({
          id: session.id,
          startDate: new Date(session.startTime),
          startTime: format(new Date(session.startTime), "HH:mm"),
          endTime: format(new Date(session.endTime), "HH:mm"),
          isAvailable: session.isAvailable,
        }));
        setSessions(formattedSessions);
      }
    }
  }, [classData, form]);
  
  // Create class mutation
  const createClass = useMutation({
    mutationFn: async (data: ClassFormValues) => {
      const response = await apiRequest("POST", "/api/classes", data);
      return response.json();
    },
    onSuccess: (newClass: Class) => {
      queryClient.invalidateQueries({ queryKey: ['/api/classes'] });
      
      // Create sessions if any
      if (sessions.length > 0) {
        sessions.forEach(async (session) => {
          const startDate = new Date(session.startDate);
          const [startHours, startMinutes] = session.startTime.split(":").map(Number);
          const [endHours, endMinutes] = session.endTime.split(":").map(Number);
          
          startDate.setHours(startHours, startMinutes);
          const endDate = new Date(startDate);
          endDate.setHours(endHours, endMinutes);
          
          const sessionData = {
            classId: newClass.id,
            startTime: startDate.toISOString(),
            endTime: endDate.toISOString(),
            isAvailable: session.isAvailable,
          };
          
          await apiRequest("POST", "/api/sessions", sessionData);
        });
      }
      
      toast({
        title: "Class created",
        description: "The class has been created successfully.",
      });
      
      navigate("/admin/classes");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create class",
        variant: "destructive",
      });
    },
  });
  
  // Update class mutation
  const updateClass = useMutation({
    mutationFn: async (data: ClassFormValues) => {
      const response = await apiRequest("PUT", `/api/classes/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/classes/${id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/classes'] });
      
      toast({
        title: "Class updated",
        description: "The class has been updated successfully.",
      });
      
      navigate("/admin/classes");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update class",
        variant: "destructive",
      });
    },
  });
  
  // Function to add a new session
  const addSession = () => {
    setSessions([
      ...sessions,
      {
        startDate: new Date(),
        startTime: "09:00",
        endTime: "10:00",
        isAvailable: true,
      },
    ]);
  };
  
  // Function to remove a session
  const removeSession = (index: number) => {
    setSessions(sessions.filter((_, i) => i !== index));
  };
  
  // Handle session field changes
  const updateSessionField = (index: number, field: string, value: any) => {
    const updatedSessions = [...sessions];
    updatedSessions[index] = {
      ...updatedSessions[index],
      [field]: value,
    };
    setSessions(updatedSessions);
  };
  
  // Handle form submission
  const onSubmit = (values: ClassFormValues) => {
    if (id) {
      updateClass.mutate(values);
      
      // Handle sessions updates separately
      // This is simplified - in a real app you'd need to handle
      // creating, updating, and deleting sessions appropriately
    } else {
      createClass.mutate(values);
    }
  };
  
  // Redirect if not admin
  useEffect(() => {
    if (!userLoading && !isAdmin(user)) {
      navigate("/login");
    }
  }, [user, userLoading, navigate]);
  
  if (userLoading || (id && classLoading)) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex justify-center items-center h-[calc(100vh-64px)]">
          <div className="animate-pulse text-gray-500">Loading...</div>
        </div>
      </div>
    );
  }
  
  if (!isAdmin(user)) {
    return null; // Redirecting in useEffect
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="flex h-[calc(100vh-64px)]">
        <AdminNavbar />
        
        <main className="flex-1 p-6 overflow-auto">
          <div className="mb-6 flex justify-between items-center">
            <div>
              <Button
                variant="ghost"
                className="mb-2"
                onClick={() => navigate("/admin/classes")}
              >
                <ArrowLeft className="h-4 w-4 mr-1" /> Back to Classes
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">
                {id ? "Edit Class" : "Create New Class"}
              </h1>
            </div>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Class Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter class title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Enter detailed description" 
                              className="min-h-[120px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location</FormLabel>
                            <FormControl>
                              <Input placeholder="Class location" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="instructor"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Instructor</FormLabel>
                            <FormControl>
                              <Input placeholder="Instructor name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Price</FormLabel>
                            <FormControl>
                              <Input placeholder="Free or price" {...field} />
                            </FormControl>
                            <FormDescription>
                              Leave empty if free
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="maxCapacity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Maximum Capacity</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="1" 
                                placeholder="Max students" 
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="categoryId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select 
                            onValueChange={(value) => field.onChange(parseInt(value))}
                            defaultValue={field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories.map((category) => (
                                <SelectItem 
                                  key={category.id} 
                                  value={category.id.toString()}
                                >
                                  {category.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
                
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Contact Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="contactEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Email</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="Email for inquiries" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="contactPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Phone</FormLabel>
                            <FormControl>
                              <Input placeholder="Phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle>Class Sessions</CardTitle>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm" 
                        onClick={addSession}
                      >
                        <PlusCircle className="h-4 w-4 mr-1" /> Add Session
                      </Button>
                    </CardHeader>
                    <CardContent>
                      {sessions.length === 0 ? (
                        <div className="text-center p-6 text-gray-500">
                          <CalendarPlus className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                          <p>No sessions added yet</p>
                          <p className="text-sm">Click "Add Session" to schedule class times</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {sessions.map((session, index) => (
                            <div key={index} className="border rounded-md p-4 relative">
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                className="absolute top-2 right-2 h-8 w-8 p-0"
                                onClick={() => removeSession(index)}
                              >
                                <Trash className="h-4 w-4 text-gray-500" />
                              </Button>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                  <label className="text-sm font-medium text-gray-700 block mb-1">
                                    Date
                                  </label>
                                  <Popover>
                                    <PopoverTrigger asChild>
                                      <Button
                                        variant="outline"
                                        className={cn(
                                          "w-full justify-start text-left font-normal",
                                          !session.startDate && "text-gray-400"
                                        )}
                                      >
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {session.startDate ? (
                                          format(session.startDate, "PPP")
                                        ) : (
                                          <span>Pick a date</span>
                                        )}
                                      </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0">
                                      <Calendar
                                        mode="single"
                                        selected={session.startDate}
                                        onSelect={(date) => date && updateSessionField(index, "startDate", date)}
                                      />
                                    </PopoverContent>
                                  </Popover>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-2">
                                  <div>
                                    <label className="text-sm font-medium text-gray-700 block mb-1">
                                      Start Time
                                    </label>
                                    <Input
                                      type="time"
                                      value={session.startTime}
                                      onChange={(e) => updateSessionField(index, "startTime", e.target.value)}
                                    />
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-gray-700 block mb-1">
                                      End Time
                                    </label>
                                    <Input
                                      type="time"
                                      value={session.endTime}
                                      onChange={(e) => updateSessionField(index, "endTime", e.target.value)}
                                    />
                                  </div>
                                </div>
                                
                                <div className="md:col-span-2 flex items-center">
                                  <input
                                    type="checkbox"
                                    id={`available-${index}`}
                                    checked={session.isAvailable}
                                    onChange={(e) => updateSessionField(index, "isAvailable", e.target.checked)}
                                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                  />
                                  <label htmlFor={`available-${index}`} className="ml-2 text-sm text-gray-700">
                                    Available for enrollment
                                  </label>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
              
              <div className="flex justify-end space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/admin/classes")}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createClass.isPending || updateClass.isPending}
                >
                  <Save className="h-4 w-4 mr-1" />
                  {id ? "Update Class" : "Create Class"}
                </Button>
              </div>
            </form>
          </Form>
        </main>
      </div>
    </div>
  );
}
